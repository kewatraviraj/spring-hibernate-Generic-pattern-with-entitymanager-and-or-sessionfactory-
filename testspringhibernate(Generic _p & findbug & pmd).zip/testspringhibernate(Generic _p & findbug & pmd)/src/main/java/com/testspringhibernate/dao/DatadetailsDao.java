/**
 * 
 */
package com.testspringhibernate.dao;

import com.testspringhibernate.model.Datadetails;

/**
 * @author Dell
 *
 */
public interface DatadetailsDao extends GenericDao<Datadetails>  {
//	void persistdata(Datadetails data);
//	List<Datadetails> listdetails();
//	boolean deletedata(int Id);
}
